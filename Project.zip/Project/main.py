import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="project101",
  database="testdb"
)
mycursor = mydb.cursor()


